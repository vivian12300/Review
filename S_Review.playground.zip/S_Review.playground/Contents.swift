/*: - Copyright :  Bulldog Ventures Inc  ©  2020 */
import UIKit

/*:

- Variables

Create a variable called name and initialize it to the name of your favorite actor, singer, or sports celebrity */
var name = "Harry Styles"
/*:
- Displaying on the screen

Display the contents of name on the screen

 Change the value of name to your name*/
name = "Vivian"
print(name)
/*:
- Constants
 
Display the contents of name

Create a constant (let instead of var) called language and initialize it to "Swift"

Display the contents of the language constant on screen

Create 3 different constants and initialize them to hold integers of your choice. Name the constants a, b, and c

Create 3 constants that are doubles (they have decimal points) Initialize them with values of your choice. Name the constants d, e, and f*/
print(name)
let language = "Swift"
print(language)
let a = 1
let b = 2
let c = 3
let d = 3.5
let e = 4.5
let f = 5.5
/*:
- Operators

Create an assortment of statements using the constants that you created that will perform the following actions - then display the equation and the result on the screen.*/
print(a+b)
print(c+b)
print(e+f)
print(f+d)
print(a*b)
print(e-f)
print(a/c)
/*:
- Add two constants
 
-                print("a + b = " ) + (a + b)

Addition sample with at least 4 constants

Subtraction sample

Division sample

Multiplication sample*/

/*:
- If Statements
 
Use the following constants to solve the problems :*/
 
let temperature = 90
let raining = true
let time = "Morning"

/*: Write a statement that tells someone to wear shorts if it is over 80 degrees, and jeans if it is less than 80 degrees. Check with the temperature constant

Check the raining constant and tell the user if they need an umbrella or not

Check the time constant and if it is morning tell the user to go to school, if it is afternoon tell the user to go home, and if it is night tell the user to go to bed*/
if temperature > 80 {
    "wear shorts"
} else {
    "wear jeans"
}

if raining == true {
    "use an umbrella"
} else {
    "don't use an umbrella"
}

if time == "Morning" {
    "Go to school"
}
if time == "Afternoon" {
    "Go home"
}
if time == "Night" {
    "Go to bed"
}
/*:
- Loops

Using a for loop print the numbers from 1 to 10 on screen

Using  a while loop print the numbers from 10 to 1 on screen*/
for n in 1...10 {
    print(n)
}
    
/*:
- Functions

Create a function that takes two doubles, multiplies them, and returns the result.

Call the function, save the result in the variable "answer". Pass it two of the constants you  creataed (a, b, c, d, e, or f)*/
func multiply(d: Double, e: Double) -> Double{
    return d*e
}
print(multiply(d: 3.5, e: 4.5))
/*:
- Closures

Create a closure that subtracts one number from another and prints the results, use the closure. You may pass it constants or numbers*/
var numbers = {(s1: Int, s2: Int) -> Int in return s1 - s2}
print(numbers(9,8))
/*:
- Enums
 
Create an enum that holds the first name of everyone in your group

Create a switch statement based on the enum that will display the birthday of the
selected person

Test it by using your own name*/
enum Names {
    case noah
    case beatriz
    case jorge
    case muhammad
    case charmarie
    case alfonso
    case vivian
}
var birthdays = Names.vivian
switch birthdays {
case .noah:
    print("Jan 2")
case .beatriz:
    print("Jan 3")
case .jorge:
    print("Jan 4")
case .muhammad:
    print("Jan 5")
case .charmarie:
    print("Jan 6")
case .alfonso:
    print("Jan 7")
case .vivian:
    print("Dec 5")
}

/*:
- Structure
 
Create a structure called Name that holds a first, middle, and last name and prints them on screen in one line with spaces between them

Create an instance of the Name structure, pass it your name, and use the instance you created to print your  name to the screen*/
struct names{
    var first = "Bob"
    var middle = "Delaney"
    var last = "Smith"
}
var fullName = names()
print("My name is \(fullName.first) \(fullName.middle) \(fullName.last).")


/*:
- Class
 
Create a class called Coffee that accepts size, caffineated,  cream,  and sugar then prints the order on screen

Create an instance of the class

Use the instance of the class and call the function*/
class Coffee {
    var size: String = "large"
    var caffineated: String = "decaf"
    var cream: String = "whole milk"
    var sugar: String = "100% sugar"
}
 
var coffeeOptions = Coffee()
print("Hello, my coffee order is a \(coffeeOptions.size) \(coffeeOptions.caffineated) with \(coffeeOptions.cream) and \(coffeeOptions.sugar).")
